﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AILaserLine : MonoBehaviour
{
    LineRenderer lineR;

    void Start()
    {
        lineR = GetComponent<LineRenderer>();
    }
    
    void Update()
    {
        transform.Rotate(Vector3.up * Time.deltaTime * 5.0f);
        RaycastHit hit;

        // 인덱스 0 포워드 * -1
        if (Physics.Raycast(transform.position, transform.forward * -1, out hit))
        {
            if (hit.collider)
            {
                lineR.SetPosition(0, hit.point);
            }
        }
        else lineR.SetPosition(0, transform.forward * -900.0f);

        // 인덱스 1 포워드
        if (Physics.Raycast(transform.position, transform.forward, out hit))
        {
            if (hit.collider)
            {
                lineR.SetPosition(1, hit.point);
            }
        }
        else lineR.SetPosition(1, transform.forward * 900.0f);

    }
}
