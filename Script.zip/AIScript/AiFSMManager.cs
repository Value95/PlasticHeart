﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public enum AIStat
{
    IDLE = 0,   // IDLE
    PATROL,     // 경로 이용
    CHASE,      // 추적

    FIGHT,      // 파이터 공격
    MCFIRE,     // 맥크리 공격
    SHOT,       // 로드호그 공격
    BOOM,       // 봄버 공격
    BEAM,       // 레이저 공격

    HARD,       // 경직
    DEAD        // 사망
}

[ExecuteInEditMode]
public class AiFSMManager : MonoBehaviour, AIIFSM
{

    [HideInInspector] public GetPrefab Pfab;
    [HideInInspector] public StatData Stat;
    
    // 상태관리
    private bool _isinit = false;
    [HideInInspector]
    public AIStat startState = AIStat.IDLE;
    private Dictionary<AIStat, AiFSMState> _states = new Dictionary<AIStat, AiFSMState>();


    // 현재상태
    private AIStat _currentState;
    public AIStat CurrentState { get { return _currentState; } }

    // 스폰 정보
    public float SpTime;

    // 경로 정보
    public GameObject Path;
    private bool PathSet;
    public bool RoundPatrol;


    // AI 정보
    [HideInInspector] public float AI_HP=100;   //실제 HP
    private float AI_currentHP;                 // 저장 HP


    // AI 상태
    [HideInInspector] public AICommu AC; float noticeTime;   // AI 소통
    [HideInInspector] public bool enemyMode=false; // 플레이어 발견하면 true 
    [HideInInspector] public bool usePath=true;    // 경로를 사용하면 PATROL


    // 플레이어 정보 : 컨트롤러
    private CharacterController _playercc;
    public CharacterController PlayerCC { get { return _playercc; } }

    // 플레이어 정보 : 위치
    private Transform _playertransform;
    public Transform PlayerTransform { get { return _playertransform; } }
    
    // AI 메쉬

    // AI 애니메이션
    private Animator _anim;
    public Animator Anim { get { return _anim; } }

    // AI 애니메이션용 변수

    // AI 애니메이션 상체
    private Transform _chest;
    public Transform Chest { get { return _chest; } }

    // AI시야
    private Camera _sight;
    public Camera Sight { get { return _sight; } }

    // AI 이동
    private NavMeshAgent _nv;
    public NavMeshAgent nv { get { return _nv; } }
    

    // 총알 스폰위치 : SHOOT, ACTIVE
    [HideInInspector]
    public Transform bulletSpw;

    // AI 래그돌
    [HideInInspector] public GameObject xbot;
    [HideInInspector] public GameObject Ragdoll;

    
    private void Awake()
    {
        // 변수 세팅
        _anim = GetComponentInChildren<Animator>();                                 // 애니메이션
        _anim.SetInteger("CurrentState", (int)CurrentState);
        _playercc = GameObject.Find("Player").GetComponent<CharacterController>();  // 플레이어
        AC = GameObject.Find("MG").GetComponent<AICommu>();                         // AI 소통 스크립트
        AC.Enemys.Add(gameObject);                                                  // 주민신고
        _playertransform = GameObject.Find("Target").transform;                     // 플레이어 트랜스폼
        _sight = GetComponentInChildren<Camera>();                                  // AI 최초 탐색 시야
        _nv = GetComponent<NavMeshAgent>();                                         // 네브 메쉬
        AI_HP = Stat.HPMax; AI_currentHP = AI_HP;                                   // 최대 체력 설정
        nv.angularSpeed = Stat.rotSpeed; nv.speed = Stat.runSpeed;                  // 회전, 이동 속도 설정
        enemyMode = false; usePath = true; PathSet = false;                         // 변수 초기화

        // AI FSM세팅
        AIStat[] statevalues = (AIStat[])System.Enum.GetValues(typeof(AIStat));
        foreach (AIStat s in statevalues)
        {
            System.Type FSMType = System.Type.GetType("AI_" + s.ToString());
            AiFSMState state = (AiFSMState)GetComponent(FSMType);
            if (null == state) { state = (AiFSMState)gameObject.AddComponent(FSMType); }
            _states.Add(s, state); state.enabled = false;
        }
    }

    private void Start()
    {
        SetState(startState); // 시작 상태로설정
        _isinit = true; // 
    }

    private void Update()
    {
        // 시작지점으로 되지 않고, 오브젝트가 있으면
        if(!PathSet&&Path)
        {
            transform.position = Path.transform.GetChild(0).position;
            PathSet = true;
        }

        // 스폰 매니저가 있으면 스폰 타이머 재생
        if (GetComponent<AISpawnManager>() && enemyMode)
        {
            if (SpTime < 0) { GetComponent<AISpawnManager>().ThisSpawn = AC.GetComponent<TriggerManager>().Spawn; GetComponent<AISpawnManager>().enabled = true; }
            else { SpTime -= Time.deltaTime; }
        }
        

        // 테스트용 단축키
        if (Input.GetKeyDown(KeyCode.N)) { enemyMode = true; SetState(AIStat.PATROL); }
        if (Input.GetKeyDown(KeyCode.M)) {
            if (CurrentState == AIStat.DEAD) { Destroy(gameObject); }
            else { AI_HP = Stat.HPMax; AI_currentHP = AI_HP; }
        }
        // 체력이 0이면 죽음
        if (AI_HP <= 0) { SetDeadState(); }
        // 체력이 깎이면 아픔
        if (AI_HP < AI_currentHP) { SetHardState(); AI_currentHP = AI_HP; }
        // 커뮤니티 체크
        CheckCommu();
    }
    
    public void SetState(AIStat newState)
    {
        if (_isinit)
        {
            _states[_currentState].enabled = false;
            _states[_currentState].EndState();
        }
        _currentState = newState;
        _states[_currentState].BeginState();
        _states[_currentState].enabled = true;
        _anim.SetInteger("CurrentState", (int)_currentState);
        
    }
    // 공격상태로 변경 Patrol, Chase
    public void AttackState()
    {
        switch(Stat.Type)
        {
            case AIType.FIGHTER:
                SetState(AIStat.FIGHT);
                break;
            case AIType.MACREE:
                SetState(AIStat.MCFIRE);
                break;
            case AIType.RODEHOG:
                SetState(AIStat.SHOT);
                break;
            case AIType.BOMBER:
                SetState(AIStat.BOOM);
                break;
            case AIType.LASER:
                SetState(AIStat.BEAM);
                break;
        }
    }

    // 플레이어를 죽이면 IDLE
    public void NotifyTargetKilled() { SetState(AIStat.IDLE); }
    // 죽음, 경직 상태로 변경
    public void SetDeadState() { SetState(AIStat.DEAD); }
    public void SetHardState() { if (AI_HP > 0) SetState(AIStat.HARD); }

    // 데미지 깎기
    public void HpDown(float damage) { AI_HP -= damage; }

    // 네비게이션을 이용한 이동 : PATROL , CHASE
    public void NvMove(Vector3 destination)
    {
        // 목표 지점 지정 후 서있지 않는다는 표시
        nv.SetDestination(destination);
        nv.isStopped = false;
    }

    // 플레이어 발견하면 Attack으로 분기 : IDLE , PATROL
    public void SeePlayerToChase()
    {
        // 카메라 내에 플레이어가 감지되면
        // 플레이어를 향해 레이캐스트
        // 플레이어가 감지되면 체이스

        Plane[] ps = GeometryUtility.CalculateFrustumPlanes(Sight);
        if(GeometryUtility.TestPlanesAABB(ps, PlayerCC.bounds))
        {
            if (Physics.Raycast(_sight.transform.position, _playertransform.position - _sight.transform.position, out RaycastHit hit))
            { if (hit.collider.gameObject.transform.root.tag == "Player") { enemyMode = true; AC.enemyNotice = true; AttackState(); } }
        }

    }

    // 목표 방향으로 회전 : CHASE
    public void See(Transform t, Vector3 SeeDir)
    {
        // 회전에 사용
        Vector3 moveDir = SeeDir - t.position;
        moveDir.y = 0;
        // 목표 방향으로 회전
        if (moveDir != Vector3.zero)
        {
            t.rotation = Quaternion.RotateTowards(
                t.rotation,
                Quaternion.LookRotation(moveDir),
                Stat.rotSpeed * Time.deltaTime);
        }
    }

    void CheckCommu()
    {
        // 에네미 모드가 아니면
        if(!enemyMode)
        {
            // 에네미모드가 알려지면 그로부터 n초 뒤 에네미모드로 바꿈
            if (AC.enemyNotice)
            {
                noticeTime += Time.deltaTime;
                if (noticeTime >= 1) { enemyMode = true; }
            }
        }

    }

    // IK애니메이션 :  SHOOT, ACTIVE
    //void OnAnimatorIK()
    //{
    //    Anim.SetIKPositionWeight(AvatarIKGoal.RightHand, 1);
    //    Anim.SetIKRotationWeight(AvatarIKGoal.RightHand, 1);
    //    Anim.SetIKPosition(AvatarIKGoal.RightHand, Target.position);
    //    Anim.SetIKRotation(AvatarIKGoal.RightHand, Target.rotation);
    //}

    // IK애니메이션 : SHOOT, ACTIVE
    //public void OnAnimIK()
    //{
    //    Chest.LookAt(Target);
    //    //Chest.rotation = Chest.rotation * Quaternion.Euler(new Vector3(20, 0, 0));
    //}
    
}
