﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AIBullet : MonoBehaviour
{
    public float damage;


    // 전진하는 코드

    private void OnTriggerEnter(Collider other)
    {
        if (other.transform.root.tag=="Player")
        { other.transform.GetComponentInParent<PlayerStats>()._HP -= damage; }
    }

}
