﻿// AI 스폰을 위한 스크립트입니다.
// 
// 스폰되는 적, 스폰 횟수, 라운드, 딜레이
// 자신이 Start되면 스폰 적 정보에 따라 AI를 스폰합니다.
// 스폰이 다 되면 

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AISpawnManager : MonoBehaviour
{
    private TriggerManager TM;

    public int ThisSpawn;
    public int NextSpawn;

    bool Act;
    bool Spawn;
    public float Dillay;

    Vector3 InstPos;

    // 스폰되는 적 정보
    public List<GameObject> AIType = new List<GameObject>();
    public List<GameObject> Path = new List<GameObject>();
    public List<bool> RoundPatrol = new List<bool>();

    private void Awake()
    {
        TM = GameObject.Find("MG").GetComponent<TriggerManager>();
        InstPos = transform.position;
    }
    void Update()
    {
        if (TM.Spawn == ThisSpawn) { Act = true; }
        else if (ThisSpawn == 0) { Act = true; }
        if (!Spawn && Act)
        {
            StartCoroutine(SpawnFunc());
            if (NextSpawn != 0) { StartCoroutine(NextRound()); }
            Spawn = true;
        }
    }
    
    IEnumerator SpawnFunc()
    {
        for (int i = 0; i < AIType.Count; i++)
        {
            yield return new WaitForSeconds(0.5f);
            CreateAI(i);
        }
    }
    IEnumerator NextRound()
    {
        yield return new WaitForSeconds(Dillay);
        TM.Spawn = NextSpawn;
        Destroy(gameObject);
    }
    void CreateAI(int i)
    {
        if (GetComponent<AiFSMManager>()) { InstPos = (Vector3) Random.insideUnitCircle * 2+transform.position; }

        var AI = (GameObject)Instantiate(AIType[i], InstPos, transform.rotation);

        if (AI.GetComponent<AiFSMManager>())
        {
            AI.GetComponent<AiFSMManager>().Path = Path[i];
            AI.GetComponent<AiFSMManager>().RoundPatrol = RoundPatrol[i];
        }
        else if (AI.GetComponent<AI_DRFIRE>())
        {
            AI.GetComponent<AI_DRFIRE>().Path = Path[i];
            AI.GetComponent<AI_DRFIRE>().RoundPatrol = RoundPatrol[i];
        }
        else
        {
            Debug.Log("! AI를 넣으세요 !");
        }
    }

}