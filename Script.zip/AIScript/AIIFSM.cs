﻿
public interface AIIFSM
{
    void SetDeadState();
    void NotifyTargetKilled();
    
}
