﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(AiFSMManager))]


public class AiFSMState : MonoBehaviour {

    protected AiFSMManager _aimanager;
    private void Awake()
    {
        _aimanager = GetComponent<AiFSMManager>();
    }

    public virtual void BeginState()
    {

    }

    public virtual void EndState()
    {

    }

}
