﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AICommu : MonoBehaviour
{
    // 생존 적 리스트
    public List<GameObject> Enemys;
    public bool enemyNotice;
    float time;

    // for UI
    public int numWave;     // 웨이브 넘버
    public float waitWave;  // 다음 웨이브 대기시간




    private void Update()
    {
        if(enemyNotice)
        {
            time += Time.deltaTime;
            if (time >= 1.5f) { enemyNotice = true; }
        }

        // 적을 다 죽였는데 웨이브가 남은 경우
        if (Enemys==null)
        {

        }
    }
}
