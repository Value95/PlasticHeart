﻿// 플레이어 불렛이 생기면 수정하기!! AIBullet -> PlayerBullet

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AIBarrier : MonoBehaviour
{
    public float MaxHP;
    [HideInInspector] public float CurrentHP;

    private void Awake() { CurrentHP = MaxHP; }
    private void Update() { if (CurrentHP <= 0 || transform.root.GetComponent<AiFSMManager>().CurrentState == AIStat.DEAD) { Destroy(gameObject); } }


}
