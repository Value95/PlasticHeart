﻿// BOOMBER 타입 AI 공격 클래스
// Anim : Aim
// In   : PATROL, CHASE
// Out  : PATROL, HARD

// 시간을 재고 ActTime이 되었다면 BoomBullet을 생성합니다.
// PATROL로 분기합니다.

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AI_BOOM : AiFSMState
{

    public override void BeginState() { base.BeginState(); SetStart(); }
    public override void EndState() { base.EndState(); }

    private float time;

    void SetStart() { time = 0; }

    private void Update()
    {
        time += Time.deltaTime;
        if (time >= _aimanager.Stat.ActTime)
        {
            Instantiate(_aimanager.Pfab.BoomPre, _aimanager.bulletSpw.position, _aimanager.bulletSpw.rotation);
            _aimanager.SetState(AIStat.PATROL);
        }

    }

}