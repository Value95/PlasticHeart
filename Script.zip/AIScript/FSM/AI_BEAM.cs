﻿// LASER 타입 AI 공격 클래스
// Anim : Beam
// In   : PATROL, CHASE
// Out  : HARD

// 액티브선을 포워드로 그리고, 고정
// 어택 타임이 되면 공격선을 쭉 그림
// 플레이어를 천천히 쫓음 (AI가회전)
// 레이에 찍히는 플레이어, AI 데미지 전달

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AI_BEAM : AiFSMState
{
    public override void BeginState() { base.BeginState(); SetStart(); }
    public override void EndState() { base.EndState(); }

    GameObject YSensor;
    float time;
    bool _Active;
    bool _Attack;

    void SetStart() { time = 0; _Attack = false; _Active = false; YSensor = transform.root.GetChild(1).gameObject; }

    private void Update()
    {
        time += Time.deltaTime;

        if(!_Active)
        {
            _Active = true;
            var Line = (GameObject)Instantiate(_aimanager.Pfab.bulletLinePre, _aimanager.bulletSpw.position, _aimanager.bulletSpw.rotation);
            Line.GetComponent<AIShootLine>().InZero = _aimanager.bulletSpw.gameObject;
            Line.GetComponent<AIShootLine>().ActTime = _aimanager.Stat.ActTime;
            Line.GetComponent<AIShootLine>().Attack = false;
            Line.GetComponent<AIShootLine>().Player = _aimanager.PlayerTransform.gameObject;
        }
        else if (time >= _aimanager.Stat.ActTime && !_Attack)
        {
            _Attack = true;
            var Line = (GameObject)Instantiate(_aimanager.Pfab.bulletLinePre, _aimanager.bulletSpw.position, _aimanager.bulletSpw.rotation);
            Line.GetComponent<AIShootLine>().InZero = _aimanager.bulletSpw.gameObject;
            Line.GetComponent<AIShootLine>().Attack = true;
            Line.GetComponent<AIShootLine>().Player = _aimanager.PlayerTransform.gameObject;

        }
        else if(time >= _aimanager.Stat.ActTime)
        { See(transform, _aimanager.PlayerTransform.position, _aimanager.Stat.rotSpeed/5); }
    }
    public void YSensorFunc()
    {
        // Y센서 사용
        Vector3 lookPos = _aimanager.PlayerTransform.position - YSensor.transform.position;
        lookPos.x = 0;

        YSensor.transform.rotation = Quaternion.RotateTowards(
                YSensor.transform.rotation,
                Quaternion.LookRotation(lookPos),
                _aimanager.Stat.rotSpeed * Time.deltaTime);

        _aimanager.bulletSpw.localEulerAngles = new Vector3(YSensor.transform.localEulerAngles.x, 0, 0);

    }

    // 목표 방향으로 회전 : CHASE
    public void See(Transform t, Vector3 SeeDir,float rotSpeed)
    {
        // 총구 들기
        YSensorFunc();
         // 회전에 사용
         Vector3 moveDir = SeeDir - t.position;
        moveDir.y = 0;
        // 목표 방향으로 회전
        if (moveDir != Vector3.zero)
        {
            t.rotation = Quaternion.RotateTowards(
                t.rotation,
                Quaternion.LookRotation(moveDir),
                rotSpeed * Time.deltaTime);
        }
    }

}
