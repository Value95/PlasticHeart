﻿// AI 공용 이동 대기상태
// Anim : Idle
// In   : PATROL, HARD
// Out  : PATROL, HARD
// 시간 (idleTime) 이 지나면 PATROL로 넘어갑니다.
// 플레이어를 발견하면 EnemyMode로 전환됩니다.

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AI_IDLE : AiFSMState
{
    private float idleTime;
    private float time = 0;

    public override void BeginState()
    {    
        base.BeginState();
        time = 0.0f;
    }

    public override void EndState()
    {
        base.EndState();
    }

    private void Start()
    {
        idleTime = _aimanager.Stat.IdleTime;
    }
    private void Update()
    {
        // PATROL 변환
        time += Time.deltaTime;
        if (time >= idleTime)
        {
            _aimanager.SetState(AIStat.PATROL);
            return;
        }

        // 플레이어 발견하면 EnemyMode
        _aimanager.SeePlayerToChase();

    }

}