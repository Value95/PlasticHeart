﻿// 근거리 공격 타입 AI 공격 클래스
// Anim : Fight
// In   : PATROL, CHASE
// Out  : PATROL, HARD

// 일정 시간 기다리고
// 공격합니다.
// 범위 내 (각도, 거리) 에 들어오면 공격합니다.
// 각도 회전은 없습니다.

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AI_FIGHT : AiFSMState
{
    float time;

    public override void BeginState() { base.BeginState();  SetStart(); }
    public override void EndState() { base.EndState(); }

    void SetStart()
    {
        time = 0;
    }

    private void Update()
    {
        time += Time.deltaTime;
        if(time>=_aimanager.Stat.ActTime)
        {
            Plane[] ps = GeometryUtility.CalculateFrustumPlanes(_aimanager.Sight);
            if (GeometryUtility.TestPlanesAABB(ps, _aimanager.PlayerCC.bounds))
            {
                _aimanager.PlayerTransform.GetComponentInParent<PlayerStats>()._HP -= _aimanager.Stat.Damage;
                _aimanager.SetState(AIStat.PATROL);
            }
            else
            {
                _aimanager.SetState(AIStat.PATROL);
            }
        }
    }

}
