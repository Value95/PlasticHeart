﻿// AI 공용 경로이용 이동
// Anim : Worlk
// In   : IDLE, Attacks, HARD
// Out  : IDLE, CHASE , Attacks, HARD

// EnemyMode가 False인 경우 경로와 경로 사이를 다닙니다.
// 포인트에 도달했을 경우 IDLE로 분기됩니다.
// EnemyMode가 True인 경우 AI_MoveTime동안 경로를 따라다닙니다.
// AI_MoveTime이 경과되면 Attacks로 분기됩니다.
// 일부 타입에선 플레이어가 일정 거리 안으로 들어오면 CHASE로 분기됩니다.

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AI_PATROL : AiFSMState
{
    [SerializeField]
    private Vector3 destination;
    private Vector3 Target;

    public bool Rot;

    bool firstSet;
    public int currentPoint;
    private bool turn;
    [SerializeField] float time;
    [SerializeField] bool set;


    public override void BeginState()
    {
        // 초기화
        time = 0;Rot = false;
        // 경로가 없으면 usePath=false;
        if (!_aimanager.Path) { _aimanager.usePath = false; }
        // 경로를 안쓰면 Chase
        if (!_aimanager.usePath) { _aimanager.SetState(AIStat.CHASE); }
        // 처음 경로를 설정하지 않는 문제
        else { if (!firstSet) { setPathPoint(); } }
        base.BeginState();
    }

    public override void EndState()
    {
        _aimanager.nv.speed = 0;

        base.EndState();
    }
    private void Update()
    {
        // 목적지 설정
        destination = getPathPoint();
        // 항상 이동
        _aimanager.NvMove(destination);
        _aimanager.nv.speed = _aimanager.Stat.runSpeed;
        // 도착하면 set
        Move();
        // 플레이어 발견하면 EnemyMode
        if (!_aimanager.enemyMode) { _aimanager.SeePlayerToChase(); }
        else { MoveEnemy(); }

    }
    void Move()
    {
        // Y까지 이동이 완료되면 IDLE
        if (Vector3.Distance(destination, transform.position) <= 0.5f)
        {
            if (!set) { setPathPoint(); set = true; }
            if (!_aimanager.enemyMode) { _aimanager.SetState(AIStat.IDLE); }
            return;
        }
        else { set = false; }
    }
    void MoveEnemy()
    {
        _aimanager.nv.angularSpeed = 0;
        if (!Rot) { See(transform, _aimanager.PlayerTransform.position); }

        // 슈터는 거리가 가까운 경우, Chase not use Path

        if (_aimanager.Stat.Type == AIType.RODEHOG|| _aimanager.Stat.Type == AIType.MACREE)
        {
            if(Vector3.Distance(_aimanager.PlayerTransform.position, transform.position) <= _aimanager.Stat.MinRange)
            {
                _aimanager.usePath = false;
                _aimanager.SetState(AIStat.CHASE);
            }
        }
        // 거리가 먼 경우, Chase not use Path
        if (Vector3.Distance(_aimanager.PlayerTransform.position, transform.position) > _aimanager.Stat.MaxRange)
        {
            _aimanager.usePath = false;
            _aimanager.SetState(AIStat.CHASE);

        }

        // 적정거리인 경우, Use Path
        // 다음지점을 향해 n초간 걷고 , 경과하면 멈추고 레이를 쏴서 플레이어 탐색
        else
        {
            time += Time.deltaTime;

            // 시간경과하면
            if(time>= _aimanager.Stat.MoveTime)
            {
                // 멈추기
                _aimanager.nv.speed = 0;
                _aimanager.nv.angularSpeed = 0;
                //레이쏘기
                Target = _aimanager.PlayerTransform.position - transform.position;
                Debug.DrawRay(transform.position, Target * 999, Color.black);
                if (Physics.Raycast(transform.position, Target * 999, out RaycastHit hitInfo))
                {
                    // 플레이어가 보이고
                    if (Rot)
                    {
                        // 플레이어가 보이면 공격
                        _aimanager.AttackState();
                        if (hitInfo.collider.gameObject.layer == 10)
                        { _aimanager.AttackState(); }

                        // 안보이면 Chase
                        else
                        {
                            _aimanager.usePath = false;
                            _aimanager.SetState(AIStat.CHASE);
                        }

                    }
                }
            }
            else
            {
                _aimanager.nv.speed = _aimanager.Stat.runSpeed;
            }
        }
    }


    public void See(Transform t, Vector3 SeeDir)
    {
        // 회전에 사용
        Vector3 moveDir = SeeDir - t.position;
        moveDir.y = 0;
        // 목표 방향으로 회전
        t.rotation = Quaternion.RotateTowards(
            t.rotation,
            Quaternion.LookRotation(moveDir),
            _aimanager.Stat.rotSpeed * Time.deltaTime);

        if(time>=_aimanager.Stat.MoveTime)
        {
            Rot = true;
        }
        else
        {
            Rot = false;
        }
    }

    // 이동할때 사용
    public Vector3 getPathPoint()
    {
        return _aimanager.Path.transform.GetChild(currentPoint).position;
    }

    // 도착하면 사용
    public void setPathPoint()
    {
        firstSet = true;
        // 말뚝
        if (_aimanager.Path.transform.childCount== 2)
        {
            currentPoint = 1;
        }
        // 순환
        else if (_aimanager.Path.transform.childCount >= 3)
        {

            // round mode
            if (_aimanager.RoundPatrol)
            {
                if (_aimanager.Path.transform.childCount - 1 == currentPoint) { currentPoint = 0; }
                else { currentPoint++; }
            }

            // turn Mode
            else
            {
                // turn 전환
                if (_aimanager.Path.transform.childCount - 1 == currentPoint) { turn = true; }
                else if (currentPoint == 0) { turn = false; }

                // 카운트
                if (!turn) { currentPoint++; } else { currentPoint--; }
            }

        }


    }



}