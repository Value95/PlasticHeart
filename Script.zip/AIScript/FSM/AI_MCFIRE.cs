﻿// MACREE 타입 AI 공격 클래스
// Anim : Aim
// In   : PATROL, CHASE
// Out  : PATROL, HARD

// BulletLine을 그립니다. (총구, 총구의 정면)
// 플레이어를 향해 회전합니다.
// ActTime-TwcTime이 지나면 타겟을 지정합니다.
// reAttack이 아닌경우 세 번 쏩니다.
// reAttack인 경우 네 번 쏩니다.
// 다 쐈다면 PATROL로 분기됩니다.

using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class AI_MCFIRE : AiFSMState
{
    public override void BeginState() { base.BeginState(); SetStart(); }
    public override void EndState() { base.EndState(); }
    
    private Vector3 PlayerPos;
    public List<Vector3> AimPos = new List<Vector3>();
    // public AK.Wwise.Event FireSound = new AK.Wwise.Event();

    private bool Attack;    // 액티브 타임이 끝났다면 true
    private bool _fire;     // 어택 쐈는지 확인
    private bool AnimFire;  // 쏜 순간 번쩍하기
    private float time;     // 시간체크
    public int ShootCount;  // 몇 번 쐈는지
    

    void SetStart()
    {
        SetAimList();       // 에임저장
        McDrawLine();       // 예상경로 그리기 
        Attack = false;     //
        time = 0;
        ShootCount = 0;
    }

    // 시간을 사용하기 때문에 업데이트에서 공격이용
    private void Update()
    {
        _aimanager.Anim.SetBool("Fire", AnimFire);// 애니메이션 파라미터

        time += Time.deltaTime;
        if (!Attack) { ActiveTime(); }
        else { Fire(); if (time >= _aimanager.Stat.BtwTime) { _fire = false; time = 0; } }
    }

    void ActiveTime()
    {
        // 액티브 타임 경과되면 어택모드로 전환
        if (time >= _aimanager.Stat.ActTime) { Attack = true; time = 0; }

    }

    void SetAimList()
    {
        AimPos.Clear(); // 초기화
        PlayerPos = _aimanager.PlayerTransform.position;

        for (int i = 0; i < _aimanager.Stat.AttackCount; i++)
        {
            float x = Random.Range(-_aimanager.Stat.BulletDeg, _aimanager.Stat.BulletDeg);
            float y = Random.Range(-_aimanager.Stat.BulletDeg, _aimanager.Stat.BulletDeg);
            float z = Random.Range(-_aimanager.Stat.BulletDeg, _aimanager.Stat.BulletDeg);
            AimPos.Add(new Vector3(PlayerPos.x + x, PlayerPos.y + y, PlayerPos.z + z));
        }
    }

    // 맥크리 예상선
    void McDrawLine()
    {
        var GunLine = (GameObject)Instantiate(_aimanager.Pfab.bulletLinePre, _aimanager.bulletSpw.position, _aimanager.bulletSpw.rotation);
        GunLine.GetComponent<AIShootLine>().InZero = _aimanager.bulletSpw.gameObject;
        GunLine.GetComponent<AIShootLine>().InOnePos = PlayerPos;
        GunLine.GetComponent<AIShootLine>().ActTime = _aimanager.Stat.ActTime - _aimanager.Stat.TwcTime;
        GunLine.GetComponent<AIShootLine>().Player = _aimanager.PlayerTransform.gameObject;


        Destroy(GunLine, _aimanager.Stat.ActTime + _aimanager.Stat.BtwTime + 0.1f);


    }

    // 맥크리 공격
    void Fire()
    {
       
       
        // 안쐈으면 쏘기
        if (!_fire)
        {
            // 50개 쐈으면 거리체크
            if (ShootCount != _aimanager.Stat.AttackCount) { FireBullet(ShootCount); }
            else
            {
                // 너무 근접이면 주먹공격
                if (Vector3.Distance(_aimanager.PlayerTransform.root.transform.position, transform.position) <= _aimanager.Stat.MinRange)
                {
                    Plane[] ps = GeometryUtility.CalculateFrustumPlanes(_aimanager.Sight);
                    if (GeometryUtility.TestPlanesAABB(ps, _aimanager.PlayerCC.bounds))
                    {
                        _aimanager.PlayerTransform.GetComponentInParent<PlayerStats>()._HP -= _aimanager.Stat.Damage;
                        _aimanager.SetState(AIStat.PATROL);
                    }
                }

                // 적당하면 패트롤
                else { _aimanager.SetState(AIStat.PATROL); }

            }
        }
    }

    void FireBullet(int i)
    {
        // FireSound.Post(gameObject);
        AnimFire = true;
        // 총알 생성 
        Vector3 InstRot = AimPos[i] - _aimanager.bulletSpw.transform.position;
        Instantiate(_aimanager.Pfab.FxGunFire_GatlingGun, _aimanager.bulletSpw.position, Quaternion.LookRotation(InstRot));
        var bullet = (GameObject)Instantiate(_aimanager.Pfab.bulletPre, _aimanager.bulletSpw.position, Quaternion.LookRotation(InstRot));
        // 총알 이동
        bullet.GetComponent<Rigidbody>().velocity = bullet.transform.forward * _aimanager.Stat.BulletSpd * Time.deltaTime;
        // 총알 정보
        bullet.GetComponent<AIBullet>().damage = _aimanager.Stat.Damage;

        // 총알 파괴
        Destroy(bullet, _aimanager.Stat.bulletLife);

        _fire = true;
        ShootCount++;
        AnimFire = false;
    }

}
