﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class AI_DEAD : AiFSMState
{
    

    public override void BeginState()
    {
        base.BeginState();

    }
    public override void EndState()
    {
        base.EndState();
    }
    private void Start()
    {
        _aimanager.AC.Enemys.Remove(gameObject); // 사망신고

        // 랙돌 
        ChangeRagdoll();
        Destroy(GetComponent<CharacterController>());
        Destroy(GetComponent<NavMeshAgent>());
        _aimanager.xbot.SetActive(false);
        _aimanager.Ragdoll.SetActive(true);
        gameObject.layer = 0;
       
    }
    

    public void ChangeRagdoll()
    {
        CopyRagdoll(_aimanager.xbot.transform, _aimanager.Ragdoll.transform);

    }

    private void CopyRagdoll(Transform origin, Transform rag)
    {
        for (int i = 0; i < origin.transform.childCount; i++)
        {
            if (origin.transform.childCount != 0)
            {
                CopyRagdoll(origin.transform.GetChild(i), rag.transform.GetChild(i));
            }
            rag.transform.GetChild(i).localPosition = origin.transform.GetChild(i).localPosition;
            rag.transform.GetChild(i).localRotation = origin.transform.GetChild(i).localRotation;
        }
    }


}