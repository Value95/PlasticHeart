﻿// AI 공용 추적 이동
// Anim : Run
// In   : PATROL, Attacks, HARD
// Out  : Attacks, HARD

// AI가 플레이어를 일정 거리(ActRange)안으로 들어올때까지 쫓아옵니다.
// (추가바람)

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AI_CHASE : AiFSMState
{
    private Vector3 destination; // 목표 방향 (플레이어나 자기 자신)
    private Vector3 Target;
    

    public float time;
    
    public override void BeginState()
    {
         base.BeginState(); time = 0;
    }

    public override void EndState() { base.EndState();  }

    private void Update()
    {
         MoveMulty();
    }

    // 추적모드
    void MoveMulty()
    {

        // 거리가 먼 경우, 플레이어 좌표로 이동
        if (Vector3.Distance(_aimanager.PlayerTransform.position, transform.position) > _aimanager.Stat.MaxRange)
        {
            _aimanager.nv.speed = _aimanager.Stat.runSpeed;
            destination = _aimanager.PlayerTransform.position;
            _aimanager.NvMove(destination);

        }

        // 슈터는 거리가 가까운 경우
        else if (Vector3.Distance(_aimanager.PlayerTransform.position, transform.position) <= _aimanager.Stat.MinRange)
        {
            // 뒷걸음
            if (_aimanager.Stat.Type == AIType.RODEHOG || _aimanager.Stat.Type == AIType.MACREE)
            {

                _aimanager.nv.speed = 0;
                _aimanager.See(gameObject.transform, _aimanager.PlayerTransform.position);
                transform.Translate(Vector3.back * (_aimanager.Stat.runSpeed/2) * Time.deltaTime);
                
            }
        }
        else
        {
            _aimanager.See(transform, _aimanager.PlayerTransform.position);
            _aimanager.nv.angularSpeed = 0;
            Target = transform.position - _aimanager.PlayerTransform.position;

            if (Physics.Raycast(_aimanager.PlayerTransform.position, Target * 999, out RaycastHit hitFromPl))
            {

                // AI에게 플레이어가 보이고 (각도 문제)
                Plane[] ps = GeometryUtility.CalculateFrustumPlanes(_aimanager.Sight);
                if (GeometryUtility.TestPlanesAABB(ps, _aimanager.PlayerCC.bounds))
                {
                    // 플레이어에게 AI가 보이면 시간재고 공격 (엄폐물 문제)
                    if (hitFromPl.collider.gameObject.layer == 11)
                    {
                        time += Time.deltaTime;
                        if (time >= _aimanager.Stat.MoveTime)
                        {
                            _aimanager.nv.angularSpeed = 0;
                            _aimanager.nv.speed = 0;
                            _aimanager.AttackState();
                        }
                    }
                    // 안보이면
                    else
                    {
                        _aimanager.nv.speed = _aimanager.Stat.runSpeed;
                        destination = hitFromPl.point;
                        _aimanager.NvMove(destination);
                    }
                }
                else
                {
                    _aimanager.See(transform, _aimanager.PlayerTransform.position);
                }
            }
        }
    }
}