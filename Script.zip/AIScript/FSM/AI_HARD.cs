﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AI_HARD : AiFSMState
{
    float time;
    public override void BeginState()
    {
        base.BeginState();
        _aimanager.NvMove(_aimanager.transform.position);
        time = 0;
    }

    public override void EndState()
    {
        base.EndState();
    }
    void Update()
    {
        time += Time.deltaTime;
        if (time >= _aimanager.Stat.HardTime)
        {
            _aimanager.SetState(AIStat.PATROL);
            _aimanager.enemyMode = true;
        }
    }

}