﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AI_DRFIRE : MonoBehaviour
{
    public AK.Wwise.Event ShotSound = new AK.Wwise.Event();

    // AI 타입 설정
    [HideInInspector] public StatData Stat;
    [HideInInspector] public GetPrefab Pfab;
    
    // 경로 정보
    public GameObject Path;
    public bool RoundPatrol;
    private int currentPoint;
    private bool turn;

    // AI 정보
    private CharacterController _cc;
    private Camera Sight;
    [HideInInspector] public AICommu AC;

    // 플레이어 정보 : 위치
    private Transform _playertransform;
    public Transform PlayerTransform { get { return _playertransform; } }

    // AI 애니메이션
    private Animator _anim;
    public Animator Anim { get { return _anim; } }
    // 총알 스폰위치
    [HideInInspector]
    public Transform bulletSpw;

    // 사망처리
    private bool Dead;
    [HideInInspector] public GameObject xbot;
    [HideInInspector] public GameObject Ragdoll;

    // 타겟지정
    private Vector3 Target;
    private int ShootCount;

    // 시간체크
    private float ChaseTime;
    private float AttackTime;
    private bool _chase;
    private bool _attack;
    private bool _fire;

    // 행동체크
    private bool _enemy;
    private bool _tackle;

    private void Awake()
    {
        // 변수 세팅 : 플레이어
        _playertransform = GameObject.Find("Target").transform;
        _cc = GetComponent<CharacterController>();
        Target = Vector3.zero;


        // AI 소통 / 주민신고
        AC = GameObject.Find("MG").GetComponent<AICommu>();
        AC.Enemys.Add(gameObject);

        // 변수 세팅 : AI
        Sight = GetComponentInChildren<Camera>();

    }
    private void Update()
    {
        // 순찰
        PatrolFunc();

        if(!_enemy)
        {
            // 감시
            KeepWatch();

        }
        else
        {

            // 시간흐름
            PassTime();

            // 공격
            AttackFunc();

            // 추적
            ChaseFunc();
        }

    }

    void KeepWatch()
    {
        Plane[] ps = GeometryUtility.CalculateFrustumPlanes(Sight);
        if (GeometryUtility.TestPlanesAABB(ps, PlayerTransform.GetComponentInParent<CharacterController>().bounds))
        {
            if (Physics.Raycast(Sight.transform.position, _playertransform.position - Sight.transform.position, out RaycastHit hit))
            { if (hit.collider.gameObject.transform.root.tag == "Player") { _enemy = true; } }
        }
    }

    void PassTime()
    {
        // 죽지않으면 시간은 흐름
        if (!Dead)
        {
            ChaseTime += Time.deltaTime;
            if (!_chase) AttackTime += Time.deltaTime;
        }
    }

    void PatrolFunc()
    {
        if (!Path) { Debug.Log("! 드론은 반드시 경로를 사용합니다 !"); }
        else
        {
            // 체이스 타임이 아니고 죽지 않았으면 이동
            if (!_chase)
            {
                if (!Dead)
                {
                    Move(getPathPoint());
                }

                if (Vector3.Distance(getPathPoint(), transform.position) < 1.0f)
                {
                    setPathPoint();
                }
            }
        }
    }

    public void Move(Vector3 targetPos)
    {
        Vector3 deltaMove = Vector3.MoveTowards(
            transform.position,
            targetPos,
            Stat.runSpeed * Time.deltaTime
            ) - transform.position;

        /*deltaMove.y = -fallSpeed * Time.deltaTime;*/
        _cc.Move(deltaMove);

        Vector3 dir = targetPos - transform.position;
        dir.y = 0;
        if (dir != Vector3.zero)
        {
            transform.rotation = Quaternion.RotateTowards(
                transform.rotation,
                Quaternion.LookRotation(dir),
                Stat.rotSpeed * Time.deltaTime
                );
        }
    }

    // 이동할때 사용
    public Vector3 getPathPoint()
    {
        return Path.transform.GetChild(currentPoint).gameObject.transform.position;
    }

    // 도착하면 사용
    public void setPathPoint()
    {
        // 말뚝
        if (Path.transform.childCount == 2)
        {
            currentPoint = 1;
        }
        // 순환
        else if (Path.transform.childCount >= 3)
        {

            // round mode
            if (RoundPatrol)
            {
                if (Path.transform.childCount - 1 == currentPoint) { currentPoint = 0; }
                else { currentPoint++; }
            }

            // turn Mode
            else
            {
                // turn 전환
                if (Path.transform.childCount - 1 == currentPoint) { turn = true; }
                else if (currentPoint == 0) { turn = false; }

                // 카운트
                if (!turn) { currentPoint++; } else { currentPoint--; }
            }

        }


    }

    void AttackFunc()
    {
        //타겟이 지정되지 않았으면 지정
        if (AttackTime >= Stat.ActTime && !_attack)
        {
            if (Target == Vector3.zero) { Target = PlayerTransform.position; }
            AttackTime = 0; _attack = true; ShootCount = 0;
        }

        // 지정이 되었으면공격
        if (_attack)
        {
            if (AttackTime >= Stat.BtwTime) { _fire = false; AttackTime = 0; }
            if (!_fire)
            {
                if (ShootCount > Stat.AttackCount) { _attack = false; Target = Vector3.zero; }
                else { FireBullet(ShootCount); }
            }
        }
    }

    void ChaseFunc()
    {
        // 체이스타임 체크
        if (ChaseTime >= Stat.MoveTime) { _chase = true; ChaseTime = 0; }
        // 체이스 타임이면 타겟 지정
        if (_chase)
        {
            //타겟 지정하고 돌격
            if (Target == Vector3.zero) { Target = PlayerTransform.position;}
            Move(Target);

            // 플레이어와 가까워졌으면 데미지 전달
            if (Vector3.Distance(_playertransform.position, transform.position) < 1.0f && !_tackle)
            { _tackle = true; _playertransform.GetComponentInParent<PlayerStats>()._HP -= Stat.Damage; }

            // 타겟 좌표와 딱 붙게 가까워졌으면 Chase = false;
            if (Vector3.Distance(Target, transform.position) < 0.1f) { _chase = false; _tackle = false; }
            // 벽과 충돌하려고 하면 Chase =false;
            Vector3 view = Target - transform.position;
            if (Physics.Raycast(transform.position, view * 1, out RaycastHit hit, 1.0f))
            { if (hit.transform.gameObject.layer == 9) { _chase = false; _tackle = false; } }

        }
    }

    // 공격용 함수
    void FireBullet(int i)
    {
        ShotSound.Post(gameObject);
        // 총알 생성 
        Vector3 InstRot = Target - bulletSpw.transform.position;
        var bullet = (GameObject)Instantiate(Pfab.bulletPre, bulletSpw.position, Quaternion.LookRotation(InstRot));
        // 총알 이동
        bullet.GetComponent<Rigidbody>().velocity = bullet.transform.forward *Stat.BulletSpd * Time.deltaTime;
        // 총알 정보
        bullet.GetComponent<AIBullet>().damage = Stat.Damage;
        // 총알 파괴
        Destroy(bullet, Stat.bulletLife);
        _fire = true;
        ShootCount++;
    }
    
    // 사망 함수
    public void SetDead()
    {
        Dead = true;
        xbot.SetActive(false); Ragdoll.SetActive(true);
        var Fx = Instantiate<GameObject>(Pfab.FxExplotion, transform.position, Quaternion.identity);
        Destroy(transform.GetComponent<AI_DRFIRE>());

    }
}
