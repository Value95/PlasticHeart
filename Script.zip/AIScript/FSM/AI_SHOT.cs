﻿// 로드호그 타입 AI 공격 클래스
// Anim : Aim
// In   : PATROL, CHASE
// Out  : PATROL, HARD

// 타겟을 지정합니다.
// 지정한 타겟을 기준으로 넓힌다.
// 짝수인 경우 홀수인 경우를 나눈다.
// ActTime이 경과하면 총알을 뿌린 후 Patrol

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AI_SHOT : AiFSMState
{
    private float time;
    private bool _fire;
    public int ShootCount;  // 몇 번 쐈는지
    private Vector3 PlayerPos;
    public List<Vector3> AimPos = new List<Vector3>();

    public override void BeginState() { base.BeginState(); SetStart(); }
    public override void EndState() { base.EndState(); }

    void SetStart()
    {
        SetAimList();       // 에임저장
        DrawLine();         // 예상경로 그리기
        time = 0; ShootCount = 0; _fire = false;
    }

    private void Update()
    {
        time += Time.deltaTime;

        // 시간이 되면 샷하고 Patrol
        if (time >= _aimanager.Stat.ActTime) { Fire(); }
    }

    void DrawLine()
    {
        var Line = (GameObject)Instantiate(_aimanager.Pfab.bulletLinePre, _aimanager.bulletSpw.position, Quaternion.LookRotation(_aimanager.bulletSpw.transform.forward));
        Line.GetComponent<AIShootLine>().InZero = _aimanager.bulletSpw.gameObject;
        Line.GetComponent<AIShootLine>().ActTime = _aimanager.Stat.TwcTime;
        Line.GetComponent<AIShootLine>().Player = _aimanager.PlayerTransform.gameObject;

    }

    void SetAimList()
    {
        AimPos.Clear(); // 초기화
        PlayerPos = _aimanager.PlayerTransform.position;

        for (int i = 0; i < _aimanager.Stat.AttackCount; i++)
        {
            float x = Random.Range(-_aimanager.Stat.BulletDeg, _aimanager.Stat.BulletDeg);
            float y = Random.Range(-_aimanager.Stat.BulletDeg, _aimanager.Stat.BulletDeg);
            float z = Random.Range(-_aimanager.Stat.BulletDeg, _aimanager.Stat.BulletDeg);
            AimPos.Add(new Vector3(PlayerPos.x + x, PlayerPos.y + y, PlayerPos.z + z));
        }
    }

    void Fire()
    {
        // 다 안쐈으면 쏘기
        if (!_fire) { FireBullet(ShootCount); }
        else { _aimanager.SetState(AIStat.PATROL); }
    }

    void FireBullet(int i)
    {
        // 총알 생성 
        Vector3 InstRot = AimPos[i] - _aimanager.bulletSpw.transform.position;
        var bullet = (GameObject)Instantiate(_aimanager.Pfab.bulletPre, _aimanager.bulletSpw.position, Quaternion.LookRotation(InstRot));
        // 총알 이동
        bullet.GetComponent<Rigidbody>().velocity = bullet.transform.forward * _aimanager.Stat.BulletSpd * Time.deltaTime;
        // 총알 정보
        bullet.GetComponent<AIBullet>().damage = _aimanager.Stat.Damage;

        // 총알 파괴
        Destroy(bullet, _aimanager.Stat.bulletLife);

        // 전부 쏘면 다쏴다 표시
        if (i >= _aimanager.Stat.AttackCount - 1) { _fire = true; }
        ShootCount++;

    }

}
