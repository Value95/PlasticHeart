﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AIBulletBoom : MonoBehaviour
{

    float bulletTime = 0f;
    GameObject Player;
    bool loose;

    void Start()
    {
        Player = GameObject.Find("Player");
    }

    void Update()
    {
        bulletTime += Time.deltaTime;

        // 플레이어에 근접하면 loose모드
        if (Vector3.Distance(Player.transform.position, transform.position) < 2f) { loose = true; }

        // 플레이어 추적
        if (!loose)
        {
            Move(transform, Player.transform.position, Player.transform.position);
        }

        // loose모드엔 직진
        else
        {
            transform.Translate(Vector3.forward * 5 * Time.deltaTime);
        }
    }
    void Move(Transform t, Vector3 SeeDir, Vector3 MovePos)
    {
        Vector3 deltaMove = Vector3.zero;

        // 회전에 사용
        Vector3 moveDir = SeeDir - t.position;

        // 목표 방향으로 회전
        if (moveDir != Vector3.zero)
        {
            t.rotation = Quaternion.RotateTowards(
                t.rotation,
                Quaternion.LookRotation(moveDir),
                150.0f * Time.deltaTime);
        }

        // 목표 지점으로 이동
        Vector3 nextMove = Vector3.MoveTowards(
            t.position,
            MovePos,
            bulletTime * Time.deltaTime);

        deltaMove = nextMove - t.position;
        gameObject.GetComponent<CharacterController>().Move(deltaMove);

    }

}
