﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteInEditMode]
public class AIShootLine : MonoBehaviour
{
    LineRenderer lineR; // 라인 렌더러

    public GameObject Player; // 플레이어

    public GameObject InZero; // 총구
    public Vector3 InOnePos; // For Mc RH

    private Vector3 pos; // 플레이어 - 자신 // x=0

    public float ActTime; // 표시선 (받음, 공통)
    public bool Attack; // 데미지용 선인지

    float time; // 초세기


    void Start()
    {
        // 변수 초기화
        lineR = GetComponent<LineRenderer>();
        time = 0;
        if (InOnePos != null) { InOnePos = InOnePos - InZero.transform.position; }
    }

    private void Update()
    {
        // 초세기
        time += Time.deltaTime;

        // 초되면 지우기 (0이면 무한)
        if (ActTime != 0 && time >= ActTime) { Destroy(gameObject); }

        // 사망하면 지우기
        if (InZero.transform.root.GetComponent<AI_DEAD>().enabled) { Destroy(gameObject); }

        // 표시선
        if (!Attack) { ActLine(); }

        // 공격선
        else { AttackLine(); }
    }
    

    void ActLine()
    {
        // 맥크리 로드호그
        if(InOnePos != null)
        {
            // 히트 포인트가 존재하는 경우
            if (Physics.Raycast(InZero.transform.position, InOnePos, out RaycastHit hitInfo))
            {
                lineR.SetPosition(0, InZero.transform.position);
                lineR.SetPosition(1, hitInfo.point);
            }
            // 히트 포인트가 존재하지 않는 경우
            else
            {
                lineR.SetPosition(0, InZero.transform.position);
                lineR.SetPosition(1, InZero.transform.forward * 900.0f);
            }
        }

        // 레이저
        else
        {
            // 히트 포인트가 존재하는 경우
            if (Physics.Raycast(InZero.transform.position, InZero.transform.forward, out RaycastHit hitInfo))
            {
                lineR.SetPosition(0, InZero.transform.position);
                lineR.SetPosition(1, hitInfo.point);
            }
            // 히트 포인트가 존재하지 않는 경우
            else
            {
                lineR.SetPosition(0, InZero.transform.position);
                lineR.SetPosition(1, InZero.transform.forward * 900.0f);
            }
        }
    }
    
    void AttackLine()
    {

        // 히트 포인트가 존재하는 경우
        if (Physics.Raycast(InZero.transform.position, InZero.transform.forward, out RaycastHit hitInfo))
        {
            lineR.SetPosition(0, InZero.transform.position);
            lineR.SetPosition(1, hitInfo.point);

            if (hitInfo.transform.root.tag == "Player")
            {
                lineR.SetColors(Color.cyan, Color.cyan);
                hitInfo.transform.GetComponentInParent<PlayerStats>()._HP -= 0.05f;
            }
            else if (hitInfo.collider.tag == "AI")
            {
                lineR.SetColors(Color.cyan, Color.cyan);
                hitInfo.collider.GetComponentInParent<AiFSMManager>().HpDown(3f);
            }
            else
            {
                lineR.SetColors(Color.blue, Color.blue);
            }
        }
        // 히트 포인트가 존재하지 않는 경우
        else
        {
            lineR.SetPosition(0, InZero.transform.position);
            lineR.SetPosition(1, InZero.transform.forward * 999);
        }
    }
}
