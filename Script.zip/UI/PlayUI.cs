﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class PlayUI : MonoBehaviour
{
    Dictionary<string, Sprite> aimList = new Dictionary<string, Sprite>();

    public List<Sprite> listAim;

    public Image aim;

    //아이템리스트
    //현재발수 / 최대탄창

    public Text nowBulletT;

    public Text maximumBullet;
    
    // Start is called before the first frame update
    void Start()
    {     
        aimList.Add("NormalAim", listAim[0]);
        aimList.Add("TargetAim", listAim[1]);
        aimList.Add("HitAim", listAim[2]);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void ChAim(string s)
    {
        aim.sprite = aimList[s];
    }
}
