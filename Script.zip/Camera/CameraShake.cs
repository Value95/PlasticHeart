﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraShake : MonoBehaviour
{
    [HideInInspector]
    public float shakeTimer = 0; //흔들림 효과 시간
    [HideInInspector]
    public float shakeAmount = 0; //흔들림 범위

    Vector3 cameraOldPos;

    private void Start()
    {
        cameraOldPos = transform.localPosition;
    }

    private void Update()
    {
        if (shakeTimer > 0)
        {
            Vector2 ShakePos = Random.insideUnitCircle * shakeAmount;

            transform.position = transform.position + new Vector3(ShakePos.x, ShakePos.y, 0);

            shakeTimer -= Time.deltaTime;
        }
        //else
            //transform.localPosition = cameraOldPos;
    }


    public void ShakeCamera(float shakePwr, float shakeDur)
    {
        shakeAmount = shakePwr;
        shakeTimer = shakeDur;
    }

}
