﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMove : MonoBehaviour
{
    [SerializeField]
    PlayerFSM playerFSM;

    [SerializeField]
    PlayerMove playerMove;

    [SerializeField]
    float mouseSensitivity; // 마우스감도

    [SerializeField]
    float speed;

    // Use this for initialization
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        FPRotate();
    }

    //Player의 회전을 담당
    void FPRotate()
    {
        //좌우 회전
        float mouseX = Input.GetAxis("Mouse X") * mouseSensitivity;
        this.transform.localRotation *= Quaternion.Euler(0, mouseX, 0);

        // 회전변수
        float mouseY = Input.GetAxis("Mouse Y");

        if (mouseX == 0)
            return;

        float tCamY = Mathf.LerpAngle(0, -mouseY, 10f);

        // CameraPosition의 각도가 180도보다 커지는경우 (상단회전) 360도를 빼서 마이너스 각도를 구함
        // -180~180도
        float angle = transform.eulerAngles.x > 180 ? transform.eulerAngles.x - 360 : transform.eulerAngles.x;

        // 구한각도에서 내가 이동할 값만큼의 각도가 제한각보다 커지면 (하단각도제한)
        if (angle + tCamY >= 80)
            angle = 80;

        // 만약 구한 각도에서 내가 이동할 값만큼의 각도가 제한각보다 작아지면(상단각도제한)
        else if (angle + tCamY <= -40)
            angle = -40;

        // 만약 제한각도의 영역이 아닌 경우
        else
            angle += tCamY;

        // 회전값 적용
        this.transform.eulerAngles = new Vector3(angle, transform.eulerAngles.y, 0);
    }

    void LateUpdate()
    {
        CameraUpdater();
    }

    void CameraUpdater()
    {
        Vector3 target;
        // 총들들면 카메라 포지션을 스르륵바꾼다.
        if(GameObject.Find("CameraFollow"))
        {
            target = GameObject.Find("CameraFollow").transform.position;
        }
        else if (playerFSM._CurrentState == Player_State.Shooting && playerMove._MStats == MoveStats.Move)
            target = GameObject.Find("CameraFollow_Shooting").transform.position;
        else
            target = GameObject.Find("CameraFollow_Normal").transform.position;

        transform.position = Vector3.Slerp(transform.position, target, speed * Time.deltaTime);
    }
}

