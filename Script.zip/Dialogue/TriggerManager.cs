﻿// TriggerManager                트리거 매니저          : 다른 스크립트에서 수를 받습니다. 다른 스크립트에서 변수의 변환을 감지합니다.
// SceneTrigger(int Scene)       씬 전환기능            : Scene이 현재 씬과 같지 않으면 Scene으로 씬 전환합니다.
// GetItem(int Item, int Count)  아이템 획득 기능       : 아이템 리스트의 Item번 아이템을 Count만큼 넣어줍니다.

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TriggerManager : MonoBehaviour
{
    public int Spawn;
    public int Dialogue;

    public void SceneTrigger(int Scene) { SceneManager.LoadScene(Scene); }

    public void GetItem(int Item, int Count)
    {

    }


}
