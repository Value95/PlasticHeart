﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class IKControl : MonoBehaviour
{
    protected Animator animator;
    public PlayerFSM player;

    public bool ikActive;

    Vector3 target;

    float interpolation = 0;
    public float _Interpolation { get { return interpolation; } set { interpolation = value; } }
    float interpolationSpeed = 0.01f;

    [SerializeField]
    Transform leftHandObj;
    [SerializeField]
    Transform camareBase;

    public Vector3 offsetL = Vector3.zero;
    public Vector3 offsetR = Vector3.zero;
    public Vector3 offsetF = Vector3.zero;

    void Start()
    {
        animator = GetComponent<Animator>();
        ikActive = true;

    }

    private void Update()
    {
        Vector3 mousePos = Input.mousePosition;
        mousePos.y = mousePos.y - 35.3f; // 35.3f 마우스와 애임의 오차범위
        Ray r = Camera.main.ScreenPointToRay(mousePos);
        RaycastHit hit;
 
        if (Physics.Raycast(r, out hit, float.MaxValue, (-1) - (1 << 9) & (-1) - (1 << 10) & (-1) - (1 << 12)))
        {
            target = hit.point;
        }
    }


    //a callback for calculating IK
    void OnAnimatorIK()
    {
        if (animator)
        { 
            if (player._CurrentState == Player_State.Idle)
            {
                animator.SetLookAtWeight(1);
                animator.SetLookAtPosition(target);
            }
            else if(player._CurrentState == Player_State.Shooting)
            {
                if(animator.GetFloat("ShootingAngle") <= -0.4f) // L
                {
                    animator.SetLookAtWeight(0.2f, 0.8f, 0.2f,0.3f,0.5f); // 머리 , 허리
                    animator.SetLookAtPosition(target - offsetL);
                }
                else if(animator.GetFloat("ShootingAngle") >= 0.4f) // R
                {
                    animator.SetLookAtWeight(0.2f, 0.8f, 0.2f, 0.3f, 0.5f); // 머리 , 허리
                    animator.SetLookAtPosition(target + offsetR);
                }
                else // F
                {
                    animator.SetLookAtWeight(0.2f, 0.8f, 0.2f, 0.3f, 0.5f); // 머리 , 허리
                    animator.SetLookAtPosition(target + offsetF);
                }
            }
        }
    }
}
