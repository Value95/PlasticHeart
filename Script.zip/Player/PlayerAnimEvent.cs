﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAnimEvent : MonoBehaviour
{
    [SerializeField]
    PlayerMove eventMove;

    [SerializeField]
    PlayerAttack attack;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void EventEndRoll()
    {
        eventMove.EndRoll();
    }

    void EventStartJump()
    {
        eventMove.StartJump();
    }

    void EventEndJump()
    {
        eventMove.EndJump();
    }

    void EventEndDash()
    {
        eventMove.EndDash();
    }

    public void EventStartAttack()
    {
        attack._isRotate = true;
    }

    public void EventAttackOn()
    {
        attack.AttackOn();
    }

    public void EventAttackOff()
    {
        attack.AttackOff();
    }

    public void EventSoundMove()
    {
        eventMove.SoundMove();
    }
}
