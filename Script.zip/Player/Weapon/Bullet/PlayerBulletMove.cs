﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBulletMove : MonoBehaviour
{
    public float speed;

    [HideInInspector]
    public Queue<Vector3> rootPos = new Queue<Vector3>();

    Vector3 nextPos;
    // Start is called before the first frame update
    void Start()
    {
        nextPos = rootPos.Dequeue();
    }

    // Update is called once per frame
    void Update()
    {
        if (rootPos.Count == 0)
            this.gameObject.SetActive(false);

        if (nextPos == transform.position)
            nextPos = rootPos.Dequeue();
        else
            transform.position = Vector3.MoveTowards(transform.position, nextPos, speed * Time.deltaTime);

    }


}
