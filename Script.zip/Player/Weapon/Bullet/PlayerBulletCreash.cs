﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBulletCreash : MonoBehaviour
{
    public float damage;

    [SerializeField]
    GameObject AIeffect;

    [SerializeField]
    GameObject Welleffect;

    private void OnTriggerEnter(Collider col)
    {
        if (col.tag == "Player")
        {
            return;
        }

        if (col.transform.root.tag == "AI")
        {
            // 드론타입을 제외한 AI들은 HpDown을 사용합니다.
            if(col.transform.GetComponent<AIBarrier>())
            {
                col.transform.GetComponent<AIBarrier>().CurrentHP -= damage;
            }
            else if (col.transform.GetComponentInParent<AiFSMManager>())
            {
                col.transform.GetComponentInParent<AiFSMManager>().HpDown(damage);
            }
            // 드론타입은 즉사시킵니다.
            else if (col.transform.GetComponentInParent<AI_DRFIRE>())
            {
                col.transform.GetComponentInParent<AI_DRFIRE>().SetDead();
            }
            GameObject Aieffect = Instantiate(AIeffect, transform.position, transform.rotation);
            if (this.name == "Bullet")
            {
                Destroy(gameObject);
            }
            Destroy(Aieffect, 0.2f);

            GameObject.Find("Player").GetComponent<PlayerShooting>().hitTime = 0.3f;
            return;
        }
        
        GameObject welleffect = Instantiate(Welleffect, transform.position, transform.rotation);
        Destroy(welleffect, 0.2f);

        if (this.name == "Bullet")
        {
            Destroy(gameObject);
        }
    }
}
