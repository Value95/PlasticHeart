﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sword : MonoBehaviour
{
    [SerializeField] // 총의 대미지
    private float damage;
    public float _Damage { get { return damage; } set { damage = value; } }


    private void OnTriggerEnter(Collider col)
    {
        if (col.tag != "Player")
        {
            if (col.tag == "AI")
            {
                col.GetComponent<AiFSMManager>().HpDown(damage);
                Destroy(col.gameObject);
            }
        }
    }
}
