﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponManager : MonoBehaviour
{
    [SerializeField]
    PlayUI UiMG;

    public string nowWeapon;

    [SerializeField]
    private Gun nowGun; // 내가 들고있는 (총)무기의 속성
    public Gun _NowGun { get { return nowGun; } set { nowGun = value; } }

    [SerializeField]
    private Sword nowSword; // 내가 들고있는 (근접)무기의 속성
    public Sword _NowSword { get { return nowSword; } set { nowSword = value; } }

    [SerializeField]
    private BoxCollider swordCol;
    public BoxCollider _SwordCol { get { return swordCol; } set { swordCol = value; } }

    // Start is called before the first frame update
    void Awake()
    {
        
    }

    private void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (nowGun)
            UiMG.nowBulletT.text = nowGun._NowBullet.ToString();
    }
}
