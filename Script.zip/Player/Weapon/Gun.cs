﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gun : MonoBehaviour {

    [SerializeField] // 총의 사거리
    private float shootingRange;
    public float _ShootingRange { get { return shootingRange; } }

    [SerializeField] //shooting per minute 분당발사수
    private float spm; 
    public float _SPM { get { return spm; } }

    public GameObject bulletObj; // 총알

    [SerializeField] // 현재 총알량
    private int nowBullet;
    public int _NowBullet { get { return nowBullet; } set { nowBullet = value; } }

    [SerializeField] // 총알 최대량
    private int maximumBullet;
    public int _MaximumBullet { get { return maximumBullet; } set { maximumBullet = value; } }

    [SerializeField] // 남은 탄약갯수
    private int totalBullet;
    public int _TotalBullet { get { return totalBullet; } set { totalBullet = value; } }


    private void Start()
    {
        
    }

    // Update is called once per frame
    void Update () {
	}
}
