﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerSwap : FSMState
{
    int weaponNum = 1;

    void OnEnable()
    {

        WeaponSwap();
    }
    
    private void Start()
    {
    }

    // Update is called once per frame
    void Update () {
		
	}
 
    void WeaponSwap()
    {
        //총이면 칼
        // 칼이면총
        if (_manager._WeaponMG.nowWeapon == "Sword")
            _manager._WeaponMG.nowWeapon = "Gun";
        else if (_manager._WeaponMG.nowWeapon == "Gun")
            _manager._WeaponMG.nowWeapon = "Sword";

        EndSwap();
    }

    void EndSwap()
    {
        _manager.ChScript(Player_State.Idle);
    }
}
