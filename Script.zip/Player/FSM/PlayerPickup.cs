﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerPickup : FSMState
{
    void OnEnable()
    {
      
    }
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update() // 아이템을 인벤토리에 넣어주는역활
    {
        if(_manager._PickupItem.name == "Bullet")
        {
            _manager._WeaponMG._NowGun._TotalBullet += _manager._PickupItem.count;
            Destroy(_manager._PickupItem.gameObject);
        }

        _manager.ChScript(Player_State.Idle);
    }

    void ItemAdd()
    {
   
        
    }
}
