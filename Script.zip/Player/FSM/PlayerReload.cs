﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerReload : FSMState
{
    void OnEnable()
    {
        // 남은 탄약갯수가 0일경우 현재총알량이 맥시멈과 똑같은경우 그냥바로 종료

        _manager.anim.SetInteger("State", (int)Player_State.Reload);
        StartReload();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void StartReload()
    {
        

        // 장전할총알이 30발 이하 남은경우
        if (_manager._WeaponMG._NowGun._TotalBullet <= _manager._WeaponMG._NowGun._MaximumBullet)
        {
            // 남은총알을 현재총알에넣는다
            _manager._WeaponMG._NowGun._NowBullet = _manager._WeaponMG._NowGun._TotalBullet;
            // 남은총알 0
            _manager._WeaponMG._NowGun._TotalBullet = 0;
        }
        // 총알이 10발정도있는경우
        else if (_manager._WeaponMG._NowGun._NowBullet > 0)
        {
            int bulletcount = _manager._WeaponMG._NowGun._MaximumBullet - _manager._WeaponMG._NowGun._NowBullet;

            // 맥시멈 총알 - 남은총알 만큼 총알에넣어준다.
            _manager._WeaponMG._NowGun._NowBullet += bulletcount;
            // 맥시멈 총알 - 남은총알 만큼 현재총알을 빼준다.
            _manager._WeaponMG._NowGun._TotalBullet -= bulletcount;
        }
        // 총알이 0인경우
        else if (_manager._WeaponMG._NowGun._NowBullet == 0)
        {
            // 현재총알을 맥시멈총알만큼넣어준다.
            _manager._WeaponMG._NowGun._NowBullet = _manager._WeaponMG._NowGun._MaximumBullet;
            // 남은총알을 맥시멈총알만큼 빼준다.
            _manager._WeaponMG._NowGun._TotalBullet -= _manager._WeaponMG._NowGun._MaximumBullet;
        }

        EndReload(); // 나중에 지울부분
    }

    public void EndReload() // 나중에 애니메이션이 나오면 애니메이션 뒷부분에 이벤트함수로 출력할예정
    {
        _manager.ChScript(_manager._PreviousState);
    }
}
