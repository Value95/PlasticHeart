﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAttack : FSMState
{
    bool isRotate;
    public bool _isRotate { set { isRotate = value; } }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(_manager.anim.GetFloat("MoveType") > -2)
        {
            _manager.anim.SetFloat("MoveType", Mathf.Max(_manager.anim.GetFloat("MoveType") - (3 * Time.deltaTime), -2));
        }
        // 공격은 레이어를사용할예정

        if(Input.GetMouseButtonDown(0))
            BasicAttack();

        if (isRotate)
        {
            TargetRot();
        }
    }

    void BasicAttack() // 기본평타
    {
        if (_manager.anim.GetCurrentAnimatorStateInfo(2).IsName("Attack0"))
        {
            _manager.anim.SetInteger("Attack", 1);
        }
        else if (_manager.anim.GetCurrentAnimatorStateInfo(2).IsName("Attack1"))
        {
            _manager.anim.SetInteger("Attack", 2);
        }
        else if (_manager.anim.GetCurrentAnimatorStateInfo(2).IsName("Move"))
        {
            _manager.anim.SetInteger("Attack", 0);
            _manager.anim.Play("Attack0");
            TargetRot();
        }
    }

    public void AttackOn()
    {
        _manager._WeaponMG._SwordCol.enabled = true;
    }

    public void AttackOff()
    {
        _manager._WeaponMG._SwordCol.enabled = false;
    }

    public void TargetRot()
    {
        Vector3 tempAngles = _manager.cameraBase.eulerAngles;
        tempAngles.x = tempAngles.z = 0;
        transform.eulerAngles = tempAngles;
        transform.GetChild(0).localRotation = Quaternion.identity;
        isRotate = false;
    }
}
