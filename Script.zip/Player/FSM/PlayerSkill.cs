﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerSkill : FSMState
{
    [SerializeField] //스킬 시작위치
    GameObject statePos;

    //이동한 좌표를 저장
    [SerializeField]
    Queue<Vector3> savePos;

    // 총알의좌표
    Vector3 previousPos;

    [SerializeField]
    PlayerMove move;


    [SerializeField] //이동할 총알오브젝트
    GameObject moveBullet;

    [SerializeField] //스킬 발동시 이동할 총알오브젝트
    GameObject skillBullet;

    GameObject tracer;

    float saveTime;
    public float saveTimeMax;

    // Start is called before the first frame update
    void Start()
    {
        savePos = new Queue<Vector3>();
        saveTime = 0;
    }

    void OnEnable()
    {
        //savePos.Clear();
        TracerBullet();
    }

    // Update is called once per frame
    void Update()
    {
        if (tracer)
        {
            Time.timeScale =0.1f;
            move.stats._physicalGauge = 0.1f;
            SaveRoot();
            if (Input.GetKeyDown(KeyCode.Z) || move.stats._physicalGauge == 0)
            {
                TracerBulletEnd();
            }
        }
    }

    void TracerBullet()
    {
        tracer = Instantiate(skillBullet, statePos.transform.position, Quaternion.identity);
        move.enabled = false;
    }

    void SaveRoot()
    {
        saveTime += Time.deltaTime;
        if (previousPos == tracer.transform.position || saveTime < saveTimeMax) //저장해둔좌표랑 현재좌표가같으면 움직이지 않은거
            return;

        saveTime = 0;
        savePos.Enqueue(tracer.transform.position);
        previousPos = tracer.transform.position;
    }

    public void TracerBulletEnd()
    {
        Destroy(tracer);
        Time.timeScale = 1;
        tracer = Instantiate(moveBullet, statePos.transform.position, Quaternion.identity);

        tracer.GetComponent<PlayerBulletMove>().rootPos = savePos;
        move.enabled = true;
        _manager.ChScript(Player_State.Shooting);
    }
}
