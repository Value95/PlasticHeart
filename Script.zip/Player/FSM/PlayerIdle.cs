﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerIdle : FSMState
{
    // Start is called before the first frame update
    void Start()
    {
    }

    private void OnEnable()
    {
        _manager._PreviousState = Player_State.Idle;
        
    }

    // Update is called once per frame
    void Update()
    {
        if(_manager._WeaponMG.nowWeapon =="Sword")
            _manager.anim.SetFloat("MoveType", Mathf.Min(_manager.anim.GetFloat("MoveType") + (Time.deltaTime * 3), -1));
        else if (_manager._WeaponMG.nowWeapon == "Gun")
        {
            _manager.anim.SetFloat("MoveType", Mathf.Max(_manager.anim.GetFloat("MoveType") - (Time.deltaTime * 3), 0));
        }

        //슈팅
        if (Input.GetMouseButtonDown(0))
        {
            switch (_manager._WeaponMG.nowWeapon)
            {
                case "Gun":
                    _manager.ChScript(Player_State.Shooting);
                    break;
                case "Sword":
                    _manager.ChScript(Player_State.Attack);
                    break;
            }

        }
        if (Input.GetMouseButtonDown(0))
        {
        }

        

        if (Input.GetKeyDown(KeyCode.X))
        {
            _manager.ChSwap(0);
        }

        //장전
        if (Input.GetKeyDown(KeyCode.R))
        {
            _manager.ChScript(Player_State.Reload);
        }
    }
}
