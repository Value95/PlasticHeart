﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerShooting : FSMState
{
    public AK.Wwise.Event sound = new AK.Wwise.Event();

    public Transform muzzle; // 총쏘는 위치

    [SerializeField]
    float idleTimer;

    [SerializeField]
    float ReadyTimer;

    float Timer = 0;

    [SerializeField]
    GameObject effect;

    Vector3 Target;

    [SerializeField]
    float animSpeed;
    bool shootingStart = false;
    public bool _ShootingStart { get { return shootingStart; } }

    bool state = false;
    Player_State state1;

    [HideInInspector]
    public float hitTime = 0;

    RaycastHit hit;
    Ray r;

    void Start()
    {
        Target = Vector3.zero;
    }

    void OnEnable()
    {
        state1 = _manager._PreviousState;
        _manager._PreviousState = Player_State.Shooting;
        _manager.anim.SetFloat("MoveType_1", 1);
        shootingStart = false;
        Timer = 0;
        state = true;
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.X))
            _manager.ChScript(Player_State.Idle);

        //장전
        if (Input.GetKeyDown(KeyCode.R))
            _manager.ChScript(Player_State.Reload);

        if (Input.GetKeyDown(KeyCode.Z))
            _manager.ChScript(Player_State.Skill);

        // MoveType을 천천히 1로올린다.
        if (_manager.anim.GetFloat("MoveType") < 1)
            _manager.anim.SetFloat("MoveType", Mathf.Min(_manager.anim.GetFloat("MoveType") + (Time.deltaTime * 3), 1));

        if (shootingStart) // 준비
            _manager.anim.SetFloat("MoveType_1", Mathf.Max(_manager.anim.GetFloat("MoveType_1") - (Time.deltaTime * 3), 0));
        else if (!shootingStart) // 사격
        {
            _manager.anim.SetFloat("MoveType_1", Mathf.Min(_manager.anim.GetFloat("MoveType_1") + (Time.deltaTime * 3), 1));
        }

        if(state && state1 != Player_State.Reload && state1 != Player_State.Skill)
        {
            Targetpos(muzzle);
        }

        Raycast();
       
        Timer += Time.deltaTime;
        if (idleTimer <= Timer)
        {
            shootingStart = false;
            _manager.ChScript(Player_State.Idle);
        }
        else if (ReadyTimer <= Timer && !shootingStart)
        {
            shootingStart = true;
        }
        else if (_manager._WeaponMG._NowGun._SPM <= Timer && _manager._PreviousState == Player_State.Shooting)
        {
            if (Input.GetMouseButtonDown(0))
            {
                Targetpos(muzzle);
            }
        }
        
    }

    void Raycast()
    {
        Vector3 mouseTouch = Input.mousePosition;
        mouseTouch.y = mouseTouch.y - 40.0f; // 39.0f 마우스와 애임의 오차범위
        r = Camera.main.ScreenPointToRay(mouseTouch);

        if (Physics.Raycast(r, out hit, float.MaxValue, (-1) - (1 << 9) & (-1) - (1 << 10) & (-1) - (1 << 12)))
        {
            if(hitTime > 0)
            {
                _manager._PlayUI.ChAim("HitAim");
                hitTime -= Time.deltaTime;
            }
            else if (hit.transform.root.gameObject.tag == "AI")
                _manager._PlayUI.ChAim("TargetAim");
            else
                _manager._PlayUI.ChAim("NormalAim");

            Target = hit.point;


            // hit와 자신과의 거리를 판단 가까운적이면 close의값을 1로 올려준다.
            /*if (Vector3.Distance(hit.transform.position, transform.position) == 31.25308f) // 31.25308f 충돌오브젝트와의 근접한거리
                _manager.anim.SetFloat("Close", 1);
            else
                _manager.anim.SetFloat("Close", 0);*/


        }
    }

    private void Targetpos(Transform point)
    {
        shootingStart = false;
        
        Timer = 0;

        if (_manager.anim.GetFloat("MoveType_1") < 1 || _manager.anim.GetFloat("MoveType") < 1)
            return;

        Fire(point, Target);

        state = false;
        _manager.anim.CrossFadeInFixedTime("Rebound", 0.1f); // 반동애니메이션 실행
    }

    private void Fire(Transform point, Vector3 target)
    {
        if (_manager._WeaponMG._NowGun._NowBullet <= 0)
            return;

        var bullet = (GameObject)Instantiate(_manager._WeaponMG._NowGun.bulletObj, point.position, Quaternion.LookRotation((target + Rebound(1.0f)) - point.position));
        GameObject Teffect = Instantiate(effect, point.position, muzzle.rotation);
        bullet.GetComponent<Rigidbody>().velocity = bullet.transform.forward * 1500 * Time.deltaTime;
        sound.Post(gameObject);

        Camera.main.GetComponent<CameraShake>().ShakeCamera(0.1f, 0.01f);

        _manager._WeaponMG._NowGun._NowBullet--;
        Destroy(bullet, _manager._WeaponMG._NowGun._ShootingRange);
        Destroy(Teffect, 0.2f);
    }

    Vector3 Rebound(float amout)
    {
        if (state)
             return Vector3.zero;

        var cam = GameObject.Find("CameraBase");
        if (_manager._Aiming)
        {
            cam.transform.eulerAngles = new Vector3(cam.transform.eulerAngles.x - 0.5f, cam.transform.eulerAngles.y, 0);
            return Vector3.zero;
        }

        cam.transform.eulerAngles = new Vector3(cam.transform.eulerAngles.x - 0.5f, cam.transform.eulerAngles.y, 0);
        Vector3 reBound = Random.insideUnitCircle * amout; ;

        return reBound;
    }
}
