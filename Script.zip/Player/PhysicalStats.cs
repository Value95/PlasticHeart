﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PhysicalStats : MonoBehaviour
{
    public float Dash;
    public float Roll;
    public float Slow;
}
