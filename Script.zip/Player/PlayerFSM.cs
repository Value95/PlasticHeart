﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum Gun_Name // 총들의 이름이걸이용해 스왑을할거다
{
    Normal_Gun = 0
}

public enum Player_State
{
    Idle = 0,
    Shooting,
    Reload,
    Swap,
    Pickup,
    Attack,
    Skill
}

public enum Weapon_num
{
    Sword = 0,
    Pistol = 1,
    SpecialGun = 2,
    SpecialBullet1 = 3,
    SpecialBullet2 = 4,
    NormalBullet = 5,
}

[RequireComponent(typeof(Player_State))]
public class PlayerFSM : MonoBehaviour {

    private bool _isinit = false;
    Player_State startState = Player_State.Idle;

    // 총상태를저장할변수
    private Dictionary<Player_State, FSMState> _states = new Dictionary<Player_State, FSMState>();

    [SerializeField]
    WeaponManager WeaponMG;
    public WeaponManager _WeaponMG { get { return WeaponMG; } }

    [SerializeField]
    PlayUI playUI;
    public PlayUI _PlayUI { get { return playUI; } }

    private Player_State currentState;
    public Player_State _CurrentState { get { return currentState; } }

    private Player_State previousState;
    public Player_State _PreviousState { get { return previousState; } set { previousState = value; } }

    public Animator anim;

    [SerializeField]
    int weaponSwapNum;
    public int _weaponSwapNum { get { return weaponSwapNum; } set { weaponSwapNum = value; } }

    GameObject playerGun;
    public GameObject _PlayerGun { get { return playerGun; } set { playerGun = value; } }

    public Transform cameraBase;

    PlayerStats stats;

    bool aiming = false;
    public bool _Aiming { get { return aiming; } set { aiming = value; } }

    bool slowChack = false;
    float slowSpeed = 1;

    ItemOp pickupItem;
    public ItemOp _PickupItem { get { return pickupItem; } }

    [SerializeField]
    float zoomIn, zoomOut;

    // Use this for initialization
    void Awake () {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;

        previousState = startState;
        anim = transform.GetChild(0).GetComponent<Animator>();

        stats = GetComponent<PlayerStats>();
        Player_State[] stateValues = (Player_State[])System.Enum.GetValues(typeof(Player_State));
        foreach (Player_State s in stateValues)
        {
            System.Type FSMType = System.Type.GetType("Player"+s.ToString());
            FSMState state = (FSMState)GetComponent(FSMType);
            if (null == state)
            {
                state = (FSMState)gameObject.AddComponent(FSMType);
            }
            _states.Add(s, state);
            state.enabled = false;
        }

    }

    void Start()
    {
        ChScript(startState);
        _isinit = true;
    }

    // Update is called once per frame
    void Update()
    {

        Aiming();
        ItemCheckRay();

        //비전투모드
        if (Input.GetKeyDown(KeyCode.X))
        {
            ChScript(Player_State.Idle);
        }
        if (Input.GetKeyDown(KeyCode.Q))
        {
            if (slowChack)
                slowChack = false;
            else if (!slowChack)
                slowChack = true;
        }

        if (Input.GetKeyDown(KeyCode.E))
            ChScript(Player_State.Swap);

        if (Input.GetKeyDown(KeyCode.F))
            ChScript(Player_State.Pickup);

        if (!slowChack || stats._physicalGauge == 0)
        {
            slowChack = false;
            slowSpeed = Mathf.Min(slowSpeed + Time.deltaTime, 1);
            slowMotion(slowSpeed);
        }
        else if (slowChack)
        {
            slowSpeed = Mathf.Max(slowSpeed - Time.deltaTime / 3, 0.5f);
            slowMotion(slowSpeed);
            stats._physicalGauge = stats.physicalStats.Slow;
        }
         
    }

    public void ChScript(Player_State newState)
    {
        if (_isinit)
        {
            _states[currentState].enabled = false;
            _states[currentState].EndState();
        }
        previousState = currentState;
        currentState = newState;
        _states[currentState].BeginState();
        _states[currentState].enabled = true;
    }

    void Aiming()
    {
        if (Input.GetMouseButtonDown(1))
        {
            aiming = true;
        }
        else if(Input.GetMouseButtonUp(1))
        {
            aiming = false;
        }

        if(aiming)
            Camera.main.fieldOfView = Mathf.Lerp(Camera.main.fieldOfView, zoomIn, Time.deltaTime * 8f);
        else if(!aiming)
            Camera.main.fieldOfView = Mathf.Lerp(Camera.main.fieldOfView, zoomOut, Time.deltaTime * 8f);

    }

    public void ChSwap(int num)
    {
        weaponSwapNum = num;
        ChScript(Player_State.Swap);
    }

    // 슬로우모션
    void slowMotion(float speed)
    {
        Time.timeScale = speed;
    }


    void ItemCheckRay() // 아이템을 확인하는 함수
    {
        // 박스케스트 거리만큼있는지 확인 박스에 붇친오브젝트를 변수에보관
        RaycastHit hit;
        // Physics.BoxCast (레이저를 발사할 위치, 사각형의 각 좌표의 절판 크기, 발사 방향, 충돌 결과, 회전 각도, 최대 거리)
        if (Physics.BoxCast(cameraBase.transform.position, new Vector3(2, 2, 0.1f), cameraBase.transform.forward, out hit, cameraBase.transform.rotation, 1.5f, (1 << 13)))
        {
            pickupItem = hit.transform.gameObject.GetComponent<ItemOp>();
        }
        else
        {
            pickupItem = null;
        }
    }
}