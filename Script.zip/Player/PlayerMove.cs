﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public enum MoveStats //이동 , 점프 , 구르기 , 대쉬
{
    Move = 0,
    Jump,
    Roll,
    Dash,
    Reload
}

public class PlayerMove : MonoBehaviour
{
    public AK.Wwise.Event sound = new AK.Wwise.Event();

    [SerializeField]
    float gravity;      //중력

    float speed;      //속도
    float curvesSpeed;

    [HideInInspector]
    public PlayerStats stats;
    PlayerFSM _manager;

    float curveSpeed;
    float t;
    public AnimationCurve dashac;
    public AnimationCurve rollac;

    MoveStats mStats = MoveStats.Move;
    public MoveStats _MStats { get { return mStats; } }

    float forward;
    float forwardSpeed;

    Transform myTransform;
    Transform model;

    CharacterController cc;
    Vector3 move;
    Vector3 physicalmove;

    float dashOverTime = 0.2f;
    float dashTimer = 0;
    int keyValue = -1;

    public bool shootingangle = true;

    public float Angle;

    void Awake()
    {
        myTransform = transform;
        cc = GetComponent<CharacterController>();
        model = transform.GetChild(0);
        stats = GetComponent<PlayerStats>();
        _manager = GetComponent<PlayerFSM>();
        forward = 0;
        forwardSpeed = 1;
    }

    void Update()
    {
        if (mStats == MoveStats.Roll) // 구르기
        {
            physicalmove.y -= gravity / 2 * Time.deltaTime;
            t += Time.deltaTime;
            curveSpeed = rollac.Evaluate(t);
            cc.Move((physicalmove * curveSpeed) * Time.deltaTime);
            return;
        }
        else if (Input.GetKeyDown(KeyCode.C) && stats._physicalGauge >= stats.physicalStats.Roll &&
                cc.isGrounded && mStats != MoveStats.Dash )
        {
            Roll();
            return;
        }

        if (mStats == MoveStats.Dash) // 대쉬
        {
            physicalmove.y -= gravity / 2 * Time.deltaTime;
            t += Time.deltaTime;
            curveSpeed = dashac.Evaluate(t);
            cc.Move((physicalmove * curveSpeed) * Time.deltaTime);
            return;
        }
        else if (stats._physicalGauge >= stats.physicalStats.Dash && // 슈팅상태에서 조준을하고있으면 안된다.
                 cc.isGrounded && mStats != MoveStats.Roll &&
                 (_manager._CurrentState != Player_State.Idle && _manager._WeaponMG.nowWeapon == "Gun"))
        {
            if (Dash())
                return;
        }

        // 루트모션때문에 추가한코드
        if (model.localPosition != new Vector3(0, 0, 0)) // 콘트룰러를 모델에 붙힌다.
        {
            myTransform.position = model.position;
            model.localPosition = new Vector3(0, 0, 0);
            return;
        }
        // 콘트룰러가 못가는곳일시 모델이 케릭터한테 붙는다.
        model.localPosition = new Vector3(0, 0, 0);

        if (Input.GetKey(KeyCode.LeftShift) && // 달리기
            mStats != MoveStats.Roll)
        {
            if (_manager._CurrentState == Player_State.Shooting)
            {
                _manager.ChScript(Player_State.Idle);
            }
            else
            {
                forwardSpeed = 2;
                speed = stats._RunSpeed;
            }
        }
        else
        {
            if(Input.GetKey(KeyCode.S))
                forwardSpeed = -1;
            else
                forwardSpeed = 1;
            speed = stats._WalkSpeed;
        }

        if (cc.isGrounded) // 점프
        {
            GradientCheck();

            if (_manager.anim.GetCurrentAnimatorStateInfo(0).IsName("Idle_Jump_Mid"))
                _manager.anim.Play("Idle_Jump_End");
            else if (_manager.anim.GetCurrentAnimatorStateInfo(0).IsName("Anim_moveJump_Mid"))
                _manager.anim.Play("Anim_moveJump_End");

            if (Input.GetKeyDown(KeyCode.Space) &&
                mStats != MoveStats.Roll && mStats != MoveStats.Dash && !_manager._Aiming)
            {
                mStats = MoveStats.Jump;

                if (_manager.anim.GetFloat("Forward") >= 0.1f)
                    _manager.anim.Play("Anim_moveJump_Start");
                else
                    _manager.anim.Play("Idle_Jump_Start");

                _manager.anim.SetInteger("MState", (int)mStats);
            }
        }
        else
        {
            move.y -= gravity * Time.deltaTime;
        }

        MoveCalc(10, 15); // 걷기
        if(_manager._Aiming || _manager._CurrentState == Player_State.Shooting)
            Trun();

        Balance();

        _manager.anim.SetFloat("Forward", forward);
        cc.Move(move * Time.deltaTime);
    }

    void Balance()
    {
        if (myTransform.eulerAngles.x != 0 || myTransform.eulerAngles.z != 0)   //모종의 이유로 기울어진다면 바로잡는다.
            myTransform.eulerAngles = new Vector3(0, myTransform.eulerAngles.y, 0);
    }

    void GradientCheck()
    {
        if (Physics.Raycast(myTransform.position, Vector3.down, 0.2f))
        /*경사로를 구분하기 위해 밑으로 레이를 쏘아 땅을 확인한다.
        CharacterController는 밑으로 지속적으로 Move가 일어나야 땅을 체크하는데 -y값이 너무 낮으면 조금만 경사져도 공중에 떠버리고 너무 높으면 절벽에서 떨어질때 추락하듯 바로 떨어진다.
        완벽하진 않지만 캡슐 모양의 CharacterController에서 절벽에 떨어지기 직전엔 중앙에서 밑으로 쏘아지는 레이에 아무것도 닿지 않으므로 그때만 -y값을 낮추면 경사로에도 잘 다니고
        절벽에도 자연스럽게 천천히 떨어지는 효과를 줄 수 있다.*/
        {
            move.y = -5;
        }
        else
            move.y = -1;
    }

    void MoveCalc(float ratio, float rotationSpeed) // 이동
    {
        if (_manager._Aiming)
        {
            rotationSpeed = 999;
            stats._MouseSensitivity = stats._MouseSensitivity / 2;
        }
        stats._MouseSensitivity = stats._MouseSensitivity;

        
        float tempMoveY = move.y;
        move.y = 0;
        Vector3 inputMoveXZ = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));
        float inputMoveXZMgnitude = inputMoveXZ.sqrMagnitude; 
        inputMoveXZ = myTransform.TransformDirection(inputMoveXZ);
        if (inputMoveXZMgnitude <= 1)
            inputMoveXZ *= speed;
        else
            inputMoveXZ = inputMoveXZ.normalized * speed;

        //조작 중에만 카메라의 방향에 상대적으로 캐릭터가 움직이도록 한다.
        if ((Input.GetButton("Horizontal") || Input.GetButton("Vertical")) || (_manager._Aiming || _manager._CurrentState == Player_State.Shooting))
        {
            if (Input.GetButton("Horizontal") || Input.GetButton("Vertical"))
            {
                if (forward <= forwardSpeed)
                    forward = Mathf.Min(forward + Time.deltaTime * 3, forwardSpeed);
                else if (forward > forwardSpeed)
                    forward = Mathf.Max(forward - Time.deltaTime * 3, forwardSpeed);
            }
                
            else if (forward >= 0)
                forward = Mathf.Max(forward - Time.deltaTime * 5, 0);

            Quaternion cameraRotation = Camera.main.transform.rotation;
            cameraRotation.x = cameraRotation.z = 0;    //y축만 필요하므로 나머지 값은 0으로 바꾼다.

            /*if (move == Vector3.zero && (!_manager._Aiming && _manager._CurrentState != Player_State.Shooting)) // 뒤를보고 카메라를돌려서 뒤로갈때 한바퀴도는문제를해결하기 위해서
            {
                Vector3 TempRot = model.transform.eulerAngles; // 모델의각도를 임시저장
                myTransform.transform.rotation = cameraRotation; // 플레이어를 가야할곳으로 바로 회전
                model.transform.eulerAngles = TempRot; // 모델의 각도를 플레이어가 이동전각도로 수정
                move = Vector3.MoveTowards(move, inputMoveXZ, ratio * speed);
                move.y = tempMoveY; //y값 복구
                return;
            }*/

            myTransform.rotation = Quaternion.Slerp(myTransform.rotation, cameraRotation, rotationSpeed * Time.deltaTime);

            if ((_manager._Aiming || _manager._CurrentState == Player_State.Shooting))
            {
                model.rotation = myTransform.rotation;
            }
            else if (move != Vector3.zero) // 회전애니메이션이 나오면 블랜딩트리로 회전을하게변경
            {
                // 좌우로 이동시 카메라가 바라보는곳을 지나면서 회전하도록
                Quaternion characterRotation = Quaternion.LookRotation(move);
                characterRotation.x = characterRotation.z = 0;
                model.rotation = Quaternion.Slerp(model.rotation, characterRotation, rotationSpeed * Time.deltaTime);
            }
            else if(move == Vector3.zero)
            {
                Vector3 TempRot = model.transform.eulerAngles; // 모델의각도를 임시저장
                myTransform.transform.rotation = cameraRotation; // 플레이어를 가야할곳으로 바로 회전
                model.transform.eulerAngles = TempRot; // 모델의 각도를 플레이어가 이동전각도로 수정
                move = Vector3.MoveTowards(move, inputMoveXZ, ratio * speed);
                move.y = tempMoveY; //y값 복구
            }
            //관성을 위해 MoveTowards를 활용하여 서서히 이동하도록 한다.
            move = Vector3.MoveTowards(move, inputMoveXZ, ratio * speed);
        }
        else
        {
            forward = Mathf.Max(forward - Time.deltaTime * 5, 0);
            forwardSpeed = 1;

            move = Vector3.MoveTowards(move, Vector3.zero, (2 - inputMoveXZMgnitude) * speed * ratio);
        }
        move.y = tempMoveY; //y값 복구

    }

    void Trun()
    {
        if(move == Vector3.zero) // 이동이없을때 마우스를돌리면 회전애니메이션을
        {

        }
        if(move != Vector3.zero && Input.GetKey(KeyCode.W))
        {
            _manager.anim.SetFloat("Trun", 0);
        }

        if (move != Vector3.zero && Input.GetKey(KeyCode.A) && !Input.GetKey(KeyCode.D)) // 왼쪽이동을할경우
        {
            if(Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.S))
                _manager.anim.SetFloat("Trun", -0.5f);
            else
                _manager.anim.SetFloat("Trun", -1);
        }
        if (move != Vector3.zero && Input.GetKey(KeyCode.D) && !Input.GetKey(KeyCode.A)) // 왼쪽이동을할경우
        {
            if(Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.S))
                _manager.anim.SetFloat("Trun", 0.5f);
            else
                _manager.anim.SetFloat("Trun", 1);
        }
    }

    bool Dash()// 대쉬
    {
        if ((Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.S) ||
            Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.W)) && keyValue == -1)
            keyValue = 0;

        if (keyValue == -1)
            return false;

        if (Input.GetKeyDown(KeyCode.W))
        {
            if (keyValue == (int)KeyCode.W && _manager._WeaponMG.nowWeapon == "Sword")
            {
                StartDash();
                return true;
            }
        }
        else if (Input.GetKeyDown(KeyCode.S))
        {
            if (keyValue == (int)KeyCode.S)
            {
                StartDash();
                return true;
            }
        }
        else if (Input.GetKeyDown(KeyCode.D))
        {
            if (keyValue == (int)KeyCode.D)
            {
                StartDash();
                return true;
            }
        }
        else if (Input.GetKeyDown(KeyCode.A))
        {
            if (keyValue == (int)KeyCode.A)
            {
                StartDash();
                return true;
            }
        }

        if (keyValue <= 0)
        {
            if (Input.GetKeyDown(KeyCode.W))
            {
                keyValue = (int)KeyCode.W;
            }
            else if (Input.GetKeyDown(KeyCode.S))
            {
                keyValue = (int)KeyCode.S;
            }
            else if (Input.GetKeyDown(KeyCode.D))
            {
                keyValue = (int)KeyCode.D;
            }
            else if (Input.GetKeyDown(KeyCode.A))
            {
                keyValue = (int)KeyCode.A;
            }
        }

        if (keyValue > 0) // 키값이있으면 타이머증가
        {
            dashTimer += Time.deltaTime;
        }

        if (dashTimer > dashOverTime) //시간이초과되면 키값을 0으로 타이머를 0으로
        {
            dashTimer = 0;
            keyValue = -1;
        }
        return false;
    }

    void StartDash() // 대쉬실행
    {
        _manager._Aiming = false;

       
        Vector3 tempAngles = _manager.cameraBase.eulerAngles;
        tempAngles.x = tempAngles.z = 0;
        myTransform.eulerAngles = tempAngles;
        model.localRotation = Quaternion.identity;

        stats._physicalGauge = stats.physicalStats.Dash;
        mStats = MoveStats.Dash;
        move.y = 0;
        dashTimer = 0;

        if (keyValue == (int)KeyCode.A)
            physicalmove = transform.TransformDirection(Vector3.left) * stats._DashSpeed;
        else if (keyValue == (int)KeyCode.D)
            physicalmove = transform.TransformDirection(Vector3.right) * stats._DashSpeed;
        else if (keyValue == (int)KeyCode.S)
            physicalmove = transform.TransformDirection(Vector3.back) * stats._DashSpeed;
        else if(keyValue == (int)KeyCode.W)
            physicalmove = transform.TransformDirection(Vector3.forward) * stats._DashSpeed;

        _manager.anim.SetInteger("DodgeLRB", keyValue);
        physicalmove.y = 0;
        if(_manager._WeaponMG.nowWeapon == "Sword")
            model.rotation = Quaternion.LookRotation(physicalmove);
        move = physicalmove / 2; // 점프상태일때 대쉬를하였을경우 점프방향으로 갈려고하는것을 대쉬방향으로 돌려줌
        keyValue = -1;
        _manager.anim.SetInteger("MState", (int)MoveStats.Dash);
        curvesSpeed = 2;
        t = 0;
    }

    void Roll()//구르기
    {
        _manager._Aiming = false;

        Vector3 tempAngles = _manager.cameraBase.eulerAngles;
        tempAngles.x = tempAngles.z = 0;
        myTransform.eulerAngles = tempAngles;
        model.localRotation = Quaternion.identity;

        stats._physicalGauge = stats.physicalStats.Roll;
        mStats = MoveStats.Roll;

        Vector3 inputMoveXZ = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));
        if (Input.GetButton("Horizontal") || Input.GetButton("Vertical"))
        {
            inputMoveXZ = inputMoveXZ.normalized;
            physicalmove = transform.TransformDirection(inputMoveXZ) * stats._RollSpeed;
        }
        else
            physicalmove = transform.TransformDirection(Vector3.forward) * stats._RollSpeed;
        
        physicalmove.y = 0;
        model.rotation = Quaternion.LookRotation(physicalmove);
        _manager.anim.SetInteger("MState", (int)mStats);
        t = 0;
    }

    public void Attitude()
    {
        float modelY = model.eulerAngles.y;
        float camerBaseY = _manager.cameraBase.eulerAngles.y;

        Angle = modelY - camerBaseY;
        float radeg = Angle * (360.0f / Mathf.PI);
        float degre = Mathf.PI * ((Angle + 90) / 180.0f);
        float Aegre = Mathf.Cos(degre);

        Angle = Mathf.Abs((int)Angle);

        if (Angle >= 0 && Angle <= 105 || Angle >= 255 && Angle <= 360)
        {
            _manager.anim.SetFloat("ShootingAngle", Aegre);
            shootingangle = true;
        }
        else if (_manager._CurrentState != Player_State.Idle)
        {
            _manager.ChScript(Player_State.Idle);
            shootingangle = false;
        }
        else
            shootingangle = false;
    }

    public void EndRoll()
    {
        mStats = MoveStats.Move;
        _manager.anim.SetInteger("MState", (int)mStats);
    }

    public void StartJump()
    {
        move.y = stats._JumpSpeed;
        if (_manager.anim.GetCurrentAnimatorStateInfo(0).IsName("Anim_moveJump_Start"))
            _manager.anim.Play("Anim_moveJump_Mid");
        else
            _manager.anim.Play("Idle_Jump_Mid");
        cc.Move(move * Time.deltaTime);
    }

    public void EndJump()
    {
        mStats = MoveStats.Move;
        _manager.anim.SetInteger("MState", (int)mStats);
    }

    public void EndDash()
    {
        mStats = MoveStats.Move;
        _manager.anim.SetInteger("MState", (int)mStats);
    }

    public void SoundMove()
    {
        sound.Post(gameObject);
    }
}