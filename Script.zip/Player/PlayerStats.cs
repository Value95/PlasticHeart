﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerStats : MonoBehaviour {

    public PhysicalStats physicalStats;

    [SerializeField]
    private Slider hp;
    public float _HP { get { return hp.value; } set { hp.value = value; } }

    [SerializeField]
    private float walkSpeed; // 걷는속도
    public float _WalkSpeed { get { return walkSpeed; } set { walkSpeed += value; } }

    [SerializeField]
    private float runSpeed; // 뛰는속도
    public float _RunSpeed { get { return runSpeed; } set { runSpeed += value; } }

    [SerializeField]
    private float rollSpeed; // 구르는속도
    public float _RollSpeed { get { return rollSpeed; } }

    [SerializeField]
    private float dashSpeed; // 대쉬속도
    public float _DashSpeed { get { return dashSpeed; } }

    [SerializeField]
    private float mouseSensitivity; //마우스감도
    public float _MouseSensitivity { get { return mouseSensitivity; } set { mouseSensitivity += value; } }

    [SerializeField]
    private float JumpSpeed; //점프력
    public float _JumpSpeed { get { return JumpSpeed; } set { JumpSpeed += value; } }

    [SerializeField]
    Slider physicalGauge;
    public float _physicalGauge { get { return physicalGauge.value; } set { physicalGauge.value -= value; Timer = 0; } }

    float Timer;
    float physicalTimer = 3;
    // Use this for initialization
    void Start () {
        Timer = 0;
	}
	
	// Update is called once per frame
	void Update () {
        Timer += Time.deltaTime;
        if (Timer >= physicalTimer)
        {
            physicalGaugeAdd();
        }
	}

    void physicalGaugeAdd()
    {
        physicalGauge.value += 1;
    }
}
